package com.example.contactos;

import android.widget.TextView;

public class Contacto {
    TextView usuario, email, twitter, telefono, fechaNac;

    public Contacto(){}
    public Contacto(TextView usuario, TextView email, TextView twitter, TextView telefono, TextView fechaNac) {
        this.usuario = usuario;
        this.email = email;
        this.twitter = twitter;
        this.telefono = telefono;
        this.fechaNac = fechaNac;
    }

    public TextView getUsuario() {
        return usuario;
    }

    public void setUsuario(TextView usuario) {
        this.usuario = usuario;
    }

    public TextView getEmail() {
        return email;
    }

    public void setEmail(TextView email) {
        this.email = email;
    }

    public TextView getTwitter() {
        return twitter;
    }

    public void setTwitter(TextView twitter) {
        this.twitter = twitter;
    }

    public TextView getTelefono() {
        return telefono;
    }

    public void setTelefono(TextView telefono) {
        this.telefono = telefono;
    }

    public TextView getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(TextView fechaNac) {
        this.fechaNac = fechaNac;
    }
}

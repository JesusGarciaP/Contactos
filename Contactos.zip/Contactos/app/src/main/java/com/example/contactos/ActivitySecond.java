package com.example.contactos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ActivitySecond extends AppCompatActivity {

EditText txtUser, txtEmail, txtTwitter, txtTelefono, txtFechaNac;
Button btnGuardar, btnCancel;
Intent i;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_segundo);
        txtUser = findViewById(R.id.txtUsuario);
        txtEmail = findViewById(R.id.txtEmail);
        txtTwitter = findViewById(R.id.txtTwitter);
        txtTelefono = findViewById(R.id.txtTelefono);
        txtFechaNac = findViewById(R.id.txtFechaNac);

        i=getIntent();

        txtUser.getText();
        txtEmail.getText();
        txtTwitter.getText();
        txtTelefono.getText();
        txtFechaNac.getText();


        btnGuardar = findViewById(R.id.btnGuardarC);
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_OK);
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==1000){
            if (requestCode==RESULT_OK){
                //Toast.makeText(this,"Mensaje enviado exitoso", Toast.LENGTH_LONG).show();
            }else if(resultCode==RESULT_CANCELED){
                //Toast.makeText(this, "mensaje no eviado"+ "Error: "+data.getStringExtra("error"),Toast.LENGTH_LONG).show();
            }
        }
    }


    public void btnCancel_click(View v){
        Intent i = new Intent();
        //i.putExtra("error", "numero no disponible");
        setResult(RESULT_CANCELED,i);
        finish();
    }
}
